
/*


    Console
    IAM

    https://768071653236.signin.aws.amazon.com/console



    EC2
    Elastic Compute Cloud (EC2)


    Elastic Beanstalk

    

*/